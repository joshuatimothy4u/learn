import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import {LoginOutput} from './login-output';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  
  baseurl="https://day2-ang.herokuapp.com/validateLogin";
  retval:boolean=false;



  constructor(private httpClient:HttpClient) 
  { 

  }

  authenticate(username:string,pass:string):Observable<LoginOutput>
  {
  
    return this.httpClient.post<LoginOutput>(this.baseurl,{"userid":username,"password":pass}).pipe(
      tap(data => console.log('All: ' + JSON.stringify(data)))
      //console.log(catchError(this.handleError))
    );
    // let obLoginOutput : LoginOutput;
    //   var parameter = "";      
    //   console.log( parameter);
  
    //   this.httpClient.post(this.baseurl,{"userid":username, "password":pass})       
    //   .subscribe(
    //   data  => {
    //   console.log(data);
      
    //   let obLoginOutput : LoginOutput =<LoginOutput>data;
    //    if(obLoginOutput.success==true)
    //    alert("Login is successful");       
    //    else
    //    alert("Login failed");
       
    //   },
    //   error  => {      
    //   console.log("Error", error);      
  
    //   return  obLoginOutput;
      
     // });  
  }

  private handleError(err:HttpErrorResponse)
  {
      let errMessage="";
      if(err.error instanceof ErrorEvent)
      {
        errMessage="Error Occurred:"+ err.error.message;
      }
      else
      {
        errMessage= "Server returned code: "+err.status +", error message is"+err.message;
      }
      return errMessage;
  }
}

