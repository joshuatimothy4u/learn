import { Component } from '@angular/core';
//import { FormsModule } from '@angular/forms';
import {LoginService} from './login-service.service';
import { LoginOutput } from './login-output';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  private _logService: LoginService;

  _username="";
  _password="";
  _loginOutput:LoginOutput=null;

  constructor(private _loginService: LoginService) { 
   // this._logService=this._loginService;
  }

  set txtUserName(value: string) {
    this._username = value;
    
  }

  set txtPassword(value: string) {
    this._password = value;
    
  }

  title = 'Angular UST Training';
   btnclick:number = 2;

authen()  
{

  this._loginService.authenticate(this._username,this._password).
  subscribe(
    data=>{this._loginOutput=<LoginOutput>data}
  );
  //this._logService.authenticate("tt","rrr");
}

   test():void{
  this.btnclick=this.btnclick+1;
}

}
