export interface LoginOutput {
    success: boolean;
    errormessage: string;
    data: Array<any>;
    }
